package com.kongzue.dialogx.dialogs;

import android.animation.Animator;
import android.content.Context;
import android.graphics.Color;
import android.text.InputFilter;
import android.text.InputType;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.kongzue.dialogx.DialogX;
import com.kongzue.dialogx.R;
import com.kongzue.dialogx.impl.AnimatorListenerEndCallBack;
import com.kongzue.dialogx.interfaces.BaseDialog;
import com.kongzue.dialogx.interfaces.DialogLifecycleCallback;
import com.kongzue.dialogx.interfaces.OnBackPressedListener;
import com.kongzue.dialogx.interfaces.OnDialogButtonClickListener;
import com.kongzue.dialogx.interfaces.OnInputDialogButtonClickListener;
import com.kongzue.dialogx.util.views.BlurView;
import com.kongzue.dialogx.util.views.DialogXBaseRelativeLayout;
import com.kongzue.dialogx.util.InputInfo;
import com.kongzue.dialogx.util.views.MaxRelativeLayout;
import com.kongzue.dialogx.util.TextInfo;

/**
 * @author: Kongzue
 * @github: https://github.com/kongzue/
 * @homepage: http://kongzue.com/
 * @mail: myzcxhh@live.cn
 * @createTime: 2020/9/21 17:08
 */
public class MessageDialog extends BaseDialog {
    
    protected MessageDialog me;
    
    private DialogLifecycleCallback<MessageDialog> dialogLifecycleCallback;
    
    public MessageDialog() {
        me = this;
    }
    
    private View dialogView;
    
    protected CharSequence title;
    protected CharSequence message;
    protected CharSequence okText;
    protected CharSequence cancelText;
    protected CharSequence otherText;
    protected String inputText;
    protected String inputHintText;
    
    protected TextInfo titleTextInfo;
    protected TextInfo messageTextInfo;
    protected TextInfo okTextInfo;
    protected TextInfo cancelTextInfo;
    protected TextInfo otherTextInfo;
    protected InputInfo inputInfo;
    
    protected OnDialogButtonClickListener okButtonClickListener;
    protected OnDialogButtonClickListener cancelButtonClickListener;
    protected OnDialogButtonClickListener otherButtonClickListener;
    
    protected int buttonOrientation;
    
    public MessageDialog(CharSequence title, CharSequence message, CharSequence okText) {
        this.title = title;
        this.message = message;
        this.okText = okText;
    }
    
    public MessageDialog(CharSequence title, CharSequence message, CharSequence okText, CharSequence cancelText) {
        this.title = title;
        this.message = message;
        this.okText = okText;
        this.cancelText = cancelText;
    }
    
    public MessageDialog(CharSequence title, CharSequence message, CharSequence okText, CharSequence cancelText, CharSequence otherText) {
        this.title = title;
        this.message = message;
        this.okText = okText;
        this.cancelText = cancelText;
        this.otherText = otherText;
    }
    
    protected DialogImpl dialogImpl;
    
    public void show() {
        int layoutId = R.layout.layout_dialogx_material;
        switch (style) {
            case STYLE_MATERIAL:
                switch (theme) {
                    case LIGHT:
                        layoutId = R.layout.layout_dialogx_material;
                        break;
                    case DARK:
                        layoutId = R.layout.layout_dialogx_material_dark;
                        break;
                }
                break;
            case STYLE_KONGZUE:
                switch (theme) {
                    case LIGHT:
                        layoutId = R.layout.layout_dialogx_kongzue;
                        break;
                    case DARK:
                        layoutId = R.layout.layout_dialogx_kongzue_dark;
                        break;
                }
                break;
            case STYLE_IOS:
                switch (theme) {
                    case LIGHT:
                        layoutId = R.layout.layout_dialogx_ios;
                        break;
                    case DARK:
                        layoutId = R.layout.layout_dialogx_ios_dark;
                        break;
                }
                break;
        }
        dialogView = createView(layoutId);
        dialogImpl = new DialogImpl(dialogView);
        show(dialogView);
    }
    
    public void refreshUI() {
        if (dialogImpl == null) return;
        dialogImpl.refreshView();
    }
    
    class DialogImpl {
        BlurView blurView;
        
        DialogXBaseRelativeLayout boxRoot;
        MaxRelativeLayout bkg;
        TextView txtDialogTitle;
        TextView txtDialogTip;
        RelativeLayout boxCustom;
        EditText txtInput;
        LinearLayout boxButton;
        TextView btnSelectOther;
        View spaceOtherButton;
        TextView btnSelectNegative;
        TextView btnSelectPositive;
        
        public DialogImpl(View convertView) {
            boxRoot = convertView.findViewById(R.id.box_root);
            bkg = convertView.findViewById(R.id.bkg);
            txtDialogTitle = convertView.findViewById(R.id.txt_dialog_title);
            txtDialogTip = convertView.findViewById(R.id.txt_dialog_tip);
            boxCustom = convertView.findViewById(R.id.box_custom);
            txtInput = convertView.findViewById(R.id.txt_input);
            boxButton = convertView.findViewById(R.id.box_button);
            btnSelectOther = convertView.findViewById(R.id.btn_selectOther);
            spaceOtherButton = convertView.findViewById(R.id.space_other_button);
            btnSelectNegative = convertView.findViewById(R.id.btn_selectNegative);
            btnSelectPositive = convertView.findViewById(R.id.btn_selectPositive);
            init();
            refreshView();
        }
        
        private void init() {
            txtDialogTitle.getPaint().setFakeBoldText(true);
            btnSelectNegative.getPaint().setFakeBoldText(true);
            btnSelectPositive.getPaint().setFakeBoldText(true);
            btnSelectOther.getPaint().setFakeBoldText(true);
            
            boxRoot.setOnLifecycleCallBack(new DialogXBaseRelativeLayout.OnLifecycleCallBack() {
                @Override
                public void onShow() {
                    isShow = true;
                    boxRoot.setAlpha(0f);
                    int enterAnimResId = R.anim.anim_dialogx_default_enter;
                    if (style == DialogX.STYLE.STYLE_IOS) {
                        enterAnimResId = R.anim.anim_dialogx_ios_enter;
                    }
                    Animation enterAnim = AnimationUtils.loadAnimation(getContext(), enterAnimResId);
                    enterAnim.setInterpolator(new DecelerateInterpolator());
                    bkg.startAnimation(enterAnim);
                    
                    boxRoot.animate().setDuration(300).alpha(1f).setInterpolator(new DecelerateInterpolator()).setDuration(300).setListener(null);
                    
                    getDialogLifecycleCallback().onShow(me);
                    
                    if (style == DialogX.STYLE.STYLE_IOS) {
                        bkg.post(new Runnable() {
                            @Override
                            public void run() {
                                int blurFrontColor = theme == DialogX.THEME.LIGHT ? Color.argb(210, 244, 245, 246) : Color.argb(220, 22, 22, 22);
                                blurView = new BlurView(bkg.getContext(), null);
                                RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(bkg.getWidth(), bkg.getHeight());
                                params.addRule(RelativeLayout.CENTER_IN_PARENT);
                                blurView.setOverlayColor(blurFrontColor);
                                blurView.setTag("blurView");
                                bkg.addView(blurView, 0, params);
                            }
                        });
                    }
                    
                    if (autoShowInputKeyboard) {
                        txtInput.postDelayed(new Runnable() {
                            @Override
                            public void run() {
                                txtInput.requestFocus();
                                txtInput.setFocusableInTouchMode(true);
                                InputMethodManager imm = (InputMethodManager) getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
                                imm.showSoftInput(txtInput, InputMethodManager.RESULT_UNCHANGED_SHOWN);
                                txtInput.setSelection(txtInput.getText().length());
                            }
                        }, 300);
                    }
                }
                
                @Override
                public void onDismiss() {
                    isShow = false;
                    getDialogLifecycleCallback().onDismiss(me);
                }
            });
        }
        
        private void refreshView() {
            bkg.setMaxWidth(DialogX.dialogMaxWidth);
            if (me instanceof InputDialog) {
                txtInput.setVisibility(View.VISIBLE);
            } else {
                txtInput.setVisibility(View.GONE);
            }
            boxRoot.setClickable(true);
            
            showText(txtDialogTitle, title);
            showText(txtDialogTip, message);
            showText(btnSelectPositive, okText);
            showText(btnSelectNegative, cancelText);
            showText(btnSelectOther, otherText);
            showText(txtInput, inputText);
            if (spaceOtherButton != null) {
                if (otherText == null) {
                    spaceOtherButton.setVisibility(View.GONE);
                } else {
                    spaceOtherButton.setVisibility(View.VISIBLE);
                }
            }
            
            useTextInfo(txtDialogTitle, titleTextInfo);
            useTextInfo(txtDialogTip, messageTextInfo);
            useTextInfo(btnSelectPositive, okTextInfo);
            useTextInfo(btnSelectNegative, cancelTextInfo);
            useTextInfo(btnSelectOther, otherTextInfo);
            if (inputInfo != null) {
                if (inputInfo.getMAX_LENGTH() != -1)
                    txtInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(inputInfo.getMAX_LENGTH())});
                int inputType = InputType.TYPE_CLASS_TEXT | inputInfo.getInputType();
                if (inputInfo.isMultipleLines()) {
                    inputType = inputType | InputType.TYPE_TEXT_FLAG_MULTI_LINE;
                }
                txtInput.setInputType(inputType);
                if (inputInfo.getTextInfo() != null)
                    useTextInfo(txtInput, inputInfo.getTextInfo());
                
                if (inputInfo.isSelectAllText()) {
                    txtInput.post(new Runnable() {
                        @Override
                        public void run() {
                            txtInput.selectAll();
                        }
                    });
                }
            }
            
            boxButton.setOrientation(buttonOrientation);
            if (buttonOrientation == LinearLayout.VERTICAL) {
                switch (style) {
                    case STYLE_IOS:
                        boxButton.removeAllViews();
                        boxButton.addView(btnSelectPositive);
                        boxButton.addView(createHorizontalSplitView(getContext().getResources().getColor(
                                theme == DialogX.THEME.LIGHT ? R.color.dialogxIOSSplitLight : R.color.dialogxIOSSplitDark
                        )));
                        boxButton.addView(btnSelectOther);
                        boxButton.addView(createHorizontalSplitView(getContext().getResources().getColor(
                                theme == DialogX.THEME.LIGHT ? R.color.dialogxIOSSplitLight : R.color.dialogxIOSSplitDark
                        )));
                        boxButton.addView(btnSelectNegative);
                        btnSelectPositive.setBackgroundResource(
                                theme == DialogX.THEME.LIGHT ? R.drawable.button_dialogx_ios_center_light : R.drawable.button_dialogx_ios_center_night
                        );
                        btnSelectOther.setBackgroundResource(
                                theme == DialogX.THEME.LIGHT ? R.drawable.button_dialogx_ios_center_light : R.drawable.button_dialogx_ios_center_night
                        );
                        btnSelectNegative.setBackgroundResource(
                                theme == DialogX.THEME.LIGHT ? R.drawable.button_dialogx_ios_bottom_light : R.drawable.button_dialogx_ios_bottom_night
                        );
                        break;
                    case STYLE_KONGZUE:
                    case STYLE_MATERIAL:
                        boxButton.removeAllViews();
                        boxButton.addView(btnSelectPositive);
                        boxButton.addView(btnSelectOther);
                        boxButton.addView(btnSelectNegative);
                        break;
                }
            } else {
                switch (style) {
                    case STYLE_MATERIAL:
                        boxButton.removeAllViews();
                        boxButton.addView(btnSelectOther);
                        if (spaceOtherButton != null) boxButton.addView(spaceOtherButton);
                        boxButton.addView(btnSelectNegative);
                        boxButton.addView(btnSelectPositive);
                        break;
                    case STYLE_KONGZUE:
                        boxButton.removeAllViews();
                        boxButton.addView(btnSelectOther);
                        boxButton.addView(btnSelectNegative);
                        boxButton.addView(btnSelectPositive);
                        break;
                    case STYLE_IOS:
                        boxButton.removeAllViews();
                        if (!isNull(cancelText)) {
                            boxButton.addView(btnSelectNegative);
                            boxButton.addView(createVerticalSplitView(getResources().getColor(
                                    theme == DialogX.THEME.LIGHT ? R.color.dialogxIOSSplitLight : R.color.dialogxIOSSplitDark
                            ),45));
                        }
                        btnSelectNegative.setBackgroundResource(
                                theme == DialogX.THEME.LIGHT ? R.drawable.button_dialogx_ios_left_light:R.drawable.button_dialogx_ios_left_night
                                );
                        if (!isNull(otherText)) {
                            boxButton.addView(btnSelectOther);
                            boxButton.addView(createVerticalSplitView(getResources().getColor(
                                    theme == DialogX.THEME.LIGHT ? R.color.dialogxIOSSplitLight : R.color.dialogxIOSSplitDark
                            ),45));
                        }
                        btnSelectOther.setBackgroundResource(
                                theme == DialogX.THEME.LIGHT ? R.drawable.button_dialogx_ios_center_light: R.drawable.button_dialogx_ios_center_night
                                );
                        boxButton.addView(btnSelectPositive);
                        if (isNull(cancelText) && isNull(otherText)) {
                            btnSelectPositive.setBackgroundResource(
                                    theme == DialogX.THEME.LIGHT ? R.drawable.button_dialogx_ios_bottom_light:R.drawable.button_dialogx_ios_bottom_night
                            );
                        } else {
                            btnSelectPositive.setBackgroundResource(
                                    theme == DialogX.THEME.LIGHT ?R.drawable.button_dialogx_ios_right_light:R.drawable.button_dialogx_ios_right_night
                            );
                        }
                        break;
                }
            }
            
            //Events
            if (cancelable) {
                boxRoot.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        doDismiss(v);
                    }
                });
            } else {
                boxRoot.setOnClickListener(null);
            }
            boxRoot.setOnBackPressedListener(new OnBackPressedListener() {
                @Override
                public boolean onBackPressed() {
                    if (cancelable) {
                        dismiss();
                    }
                    return false;
                }
            });
            btnSelectNegative.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (okButtonClickListener != null) {
                        if (okButtonClickListener instanceof OnInputDialogButtonClickListener) {
                            String s = txtInput == null ? "" : txtInput.getText().toString();
                            if (!((OnInputDialogButtonClickListener) okButtonClickListener).onClick(me, v, s)) {
                                doDismiss(v);
                            }
                        } else {
                            if (!okButtonClickListener.onClick(me, v)) {
                                doDismiss(v);
                            }
                        }
                    } else {
                        doDismiss(v);
                    }
                }
            });
            btnSelectPositive.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (cancelButtonClickListener != null) {
                        if (cancelButtonClickListener instanceof OnInputDialogButtonClickListener) {
                            String s = txtInput == null ? "" : txtInput.getText().toString();
                            if (!((OnInputDialogButtonClickListener) cancelButtonClickListener).onClick(me, v, s)) {
                                doDismiss(v);
                            }
                        } else {
                            if (!cancelButtonClickListener.onClick(me, v)) {
                                doDismiss(v);
                            }
                        }
                    } else {
                        doDismiss(v);
                    }
                }
            });
            btnSelectOther.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (otherButtonClickListener != null) {
                        if (otherButtonClickListener instanceof OnInputDialogButtonClickListener) {
                            String s = txtInput == null ? "" : txtInput.getText().toString();
                            if (!((OnInputDialogButtonClickListener) otherButtonClickListener).onClick(me, v, s)) {
                                doDismiss(v);
                            }
                        } else {
                            if (!otherButtonClickListener.onClick(me, v)) {
                                doDismiss(v);
                            }
                        }
                    } else {
                        doDismiss(v);
                    }
                }
            });
            
        }
        
        public void doDismiss(View v) {
            if (v != null) v.setEnabled(false);
            boxRoot.animate().setDuration(300).alpha(0f).setInterpolator(new AccelerateInterpolator()).setDuration(300).setListener(new AnimatorListenerEndCallBack() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    dismiss(dialogView);
                }
            });
        }
    }
    
    public void dismiss() {
        if (dialogImpl == null) return;
        dialogImpl.doDismiss(null);
    }
    
    public DialogLifecycleCallback<MessageDialog> getDialogLifecycleCallback() {
        return dialogLifecycleCallback == null ? new DialogLifecycleCallback<MessageDialog>() {
        } : dialogLifecycleCallback;
    }
    
    public MessageDialog setDialogLifecycleCallback(DialogLifecycleCallback<MessageDialog> dialogLifecycleCallback) {
        this.dialogLifecycleCallback = dialogLifecycleCallback;
        return this;
    }
    
    public MessageDialog setStyle(DialogX.STYLE style) {
        this.style = style;
        return this;
    }
    
    public MessageDialog setTheme(DialogX.THEME theme) {
        this.theme = theme;
        return this;
    }
    
    public CharSequence getOkButton() {
        return okText;
    }
    
    public MessageDialog setOkButton(CharSequence okText) {
        this.okText = okText;
        refreshUI();
        return this;
    }
    
    public CharSequence getCancelButton() {
        return cancelText;
    }
    
    public MessageDialog setCancelButton(CharSequence cancelText) {
        this.cancelText = cancelText;
        refreshUI();
        return this;
    }
    
    public CharSequence getOtherButton() {
        return otherText;
    }
    
    public MessageDialog setOtherButton(CharSequence otherText) {
        this.otherText = otherText;
        refreshUI();
        return this;
    }
    
    public OnDialogButtonClickListener getOkButtonClickListener() {
        return okButtonClickListener;
    }
    
    public MessageDialog setOkButtonClickListener(OnDialogButtonClickListener okButtonClickListener) {
        this.okButtonClickListener = okButtonClickListener;
        refreshUI();
        return this;
    }
    
    public OnDialogButtonClickListener getCancelButtonClickListener() {
        return cancelButtonClickListener;
    }
    
    public MessageDialog setCancelButtonClickListener(OnDialogButtonClickListener cancelButtonClickListener) {
        this.cancelButtonClickListener = cancelButtonClickListener;
        refreshUI();
        return this;
    }
    
    public OnDialogButtonClickListener getOtherButtonClickListener() {
        return otherButtonClickListener;
    }
    
    public MessageDialog setOtherButtonClickListener(OnDialogButtonClickListener otherButtonClickListener) {
        this.otherButtonClickListener = otherButtonClickListener;
        refreshUI();
        return this;
    }
    
    public CharSequence getTitle() {
        return title;
    }
    
    public MessageDialog setTitle(CharSequence title) {
        this.title = title;
        refreshUI();
        return this;
    }
    
    public CharSequence getMessage() {
        return message;
    }
    
    public MessageDialog setMessage(CharSequence message) {
        this.message = message;
        refreshUI();
        return this;
    }
    
    public TextInfo getTitleTextInfo() {
        return titleTextInfo;
    }
    
    public MessageDialog setTitleTextInfo(TextInfo titleTextInfo) {
        this.titleTextInfo = titleTextInfo;
        refreshUI();
        return this;
    }
    
    public TextInfo getMessageTextInfo() {
        return messageTextInfo;
    }
    
    public MessageDialog setMessageTextInfo(TextInfo messageTextInfo) {
        this.messageTextInfo = messageTextInfo;
        refreshUI();
        return this;
    }
    
    public TextInfo getOkTextInfo() {
        return okTextInfo;
    }
    
    public MessageDialog setOkTextInfo(TextInfo okTextInfo) {
        this.okTextInfo = okTextInfo;
        refreshUI();
        return this;
    }
    
    public TextInfo getCancelTextInfo() {
        return cancelTextInfo;
    }
    
    public MessageDialog setCancelTextInfo(TextInfo cancelTextInfo) {
        this.cancelTextInfo = cancelTextInfo;
        refreshUI();
        return this;
    }
    
    public TextInfo getOtherTextInfo() {
        return otherTextInfo;
    }
    
    public MessageDialog setOtherTextInfo(TextInfo otherTextInfo) {
        this.otherTextInfo = otherTextInfo;
        refreshUI();
        return this;
    }
    
    public int getButtonOrientation() {
        return buttonOrientation;
    }
    
    public MessageDialog setButtonOrientation(int buttonOrientation) {
        this.buttonOrientation = buttonOrientation;
        refreshUI();
        return this;
    }
    
    public boolean isCancelable() {
        return cancelable;
    }
    
    public MessageDialog setCancelable(boolean cancelable) {
        this.cancelable = cancelable;
        return this;
    }
    
    public OnBackPressedListener getOnBackPressedListener() {
        return onBackPressedListener;
    }
    
    public MessageDialog setOnBackPressedListener(OnBackPressedListener onBackPressedListener) {
        this.onBackPressedListener = onBackPressedListener;
        return this;
    }
}
